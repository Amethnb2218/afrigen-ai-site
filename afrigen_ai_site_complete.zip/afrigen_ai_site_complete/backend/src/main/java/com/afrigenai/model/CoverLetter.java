package com.afrigenai.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Represents a cover letter submitted by a user. The fields include basic
 * information and free-form content. Letters of recommendation can also be
 * represented using this structure.
 */
@Document(collection = "cover_letters")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CoverLetter {
    @Id
    private String id;
    private String applicantName;
    private String recipientName;
    private String subject;
    private String body;
}