package com.afrigenai.repository;

import com.afrigenai.model.Cv;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * Repository for storing CV entries.
 */
public interface CvRepository extends MongoRepository<Cv, String> {
}