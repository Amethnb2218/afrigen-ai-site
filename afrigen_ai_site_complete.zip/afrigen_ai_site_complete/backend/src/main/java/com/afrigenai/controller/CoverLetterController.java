package com.afrigenai.controller;

import com.afrigenai.model.CoverLetter;
import com.afrigenai.repository.CoverLetterRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * REST controller for managing cover letters and recommendation letters.
 */
@RestController
@RequestMapping("/api/coverletters")
public class CoverLetterController {

    private final CoverLetterRepository coverLetterRepository;

    public CoverLetterController(CoverLetterRepository coverLetterRepository) {
        this.coverLetterRepository = coverLetterRepository;
    }

    /**
     * Saves a cover letter provided by the user.
     */
    @PostMapping
    public ResponseEntity<CoverLetter> saveCoverLetter(@RequestBody CoverLetter letter) {
        CoverLetter saved = coverLetterRepository.save(letter);
        return ResponseEntity.ok(saved);
    }

    /**
     * Returns a few sample cover letter templates to guide users.
     */
    @GetMapping("/templates")
    public ResponseEntity<List<Map<String, String>>> getTemplates() {
        List<Map<String, String>> templates = new ArrayList<>();
        templates.add(Map.of(
                "name", "Motivation simple",
                "description", "Lettre de motivation concise pour un poste",
                "example", "<p>Madame, Monsieur,</p><p>Je vous écris pour postuler...</p>"
        ));
        templates.add(Map.of(
                "name", "Recommandation",
                "description", "Lettre de recommandation pour un ancien collègue",
                "example", "<p>À qui de droit,</p><p>J’ai eu l’honneur de superviser...</p>"
        ));
        return ResponseEntity.ok(templates);
    }
}