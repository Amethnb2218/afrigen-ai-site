package com.afrigenai.controller;

import com.afrigenai.model.Cv;
import com.afrigenai.repository.CvRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * REST controller handling CV creation and retrieval. This provides
 * endpoints for users to submit CV data and retrieve templates.
 */
@RestController
@RequestMapping("/api/cv")
public class CvController {

    private final CvRepository cvRepository;

    public CvController(CvRepository cvRepository) {
        this.cvRepository = cvRepository;
    }

    /**
     * Saves a CV provided by the user. The submitted JSON should match
     * the Cv entity fields.
     */
    @PostMapping
    public ResponseEntity<Cv> saveCv(@RequestBody Cv cv) {
        Cv saved = cvRepository.save(cv);
        return ResponseEntity.ok(saved);
    }

    /**
     * Returns a list of simple CV templates. In a real application,
     * templates could be stored in a database or loaded from files.
     */
    @GetMapping("/templates")
    public ResponseEntity<List<Map<String, String>>> getTemplates() {
        List<Map<String, String>> templates = new ArrayList<>();
        templates.add(Map.of(
                "name", "Moderne",
                "description", "Un modèle moderne mettant en avant vos compétences et projets",
                "example", "<h2>Nom Prénom</h2><p>Titre du poste</p><h3>Compétences</h3><ul><li>Compétence 1</li></ul>"
        ));
        templates.add(Map.of(
                "name", "Classique",
                "description", "Un modèle classique et sobre pour tout secteur",
                "example", "<h2>Nom Prénom</h2><p>Résumé professionnel</p><h3>Expériences</h3><ul><li>Poste 1</li></ul>"
        ));
        return ResponseEntity.ok(templates);
    }
}