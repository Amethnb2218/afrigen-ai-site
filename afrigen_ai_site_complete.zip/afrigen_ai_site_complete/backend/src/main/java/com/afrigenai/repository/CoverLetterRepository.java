package com.afrigenai.repository;

import com.afrigenai.model.CoverLetter;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * Repository for storing cover letters in MongoDB.
 */
public interface CoverLetterRepository extends MongoRepository<CoverLetter, String> {
}