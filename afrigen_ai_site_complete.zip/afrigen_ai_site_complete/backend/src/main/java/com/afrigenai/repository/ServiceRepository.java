package com.afrigenai.repository;

import com.afrigenai.model.Service;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * Repository interface for managing services in MongoDB.
 */
public interface ServiceRepository extends MongoRepository<Service, String> {
}