package com.afrigenai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the Afrigen AI backend application.
 */
@SpringBootApplication
public class AfrigenAiBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(AfrigenAiBackendApplication.class, args);
    }
}