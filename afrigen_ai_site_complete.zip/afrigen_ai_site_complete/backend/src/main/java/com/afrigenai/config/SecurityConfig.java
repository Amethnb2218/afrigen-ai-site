package com.afrigenai.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Basic security configuration using Spring Security. This class leaves
 * room for Keycloak integration. At present, all endpoints are permitted
 * without authentication to simplify development. Replace the permitAll()
 * calls with Keycloak configuration when you have your Keycloak server
 * details ready.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        // Disable CSRF for simplicity; enable it in production with proper configuration
        http.csrf(csrf -> csrf.disable());

        // Authorize all requests for now; secure your endpoints later
        http.authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/**").permitAll()
                .anyRequest().permitAll()
        );

        // Optional: apply default login/logout page
        http.formLogin(Customizer.withDefaults());

        return http.build();
    }
}