package com.afrigenai.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Represents a service offered by Afrigen AI. Examples include automation,
 * content creation, website creation, hosting, domain management and visual design.
 */
@Document(collection = "services")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Service {
    @Id
    private String id;
    private String title;
    private String description;
}