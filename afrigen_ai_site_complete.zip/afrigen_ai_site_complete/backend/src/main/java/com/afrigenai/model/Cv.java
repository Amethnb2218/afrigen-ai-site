package com.afrigenai.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

/**
 * Represents a CV (Curriculum Vitae) submitted by a user. The fields capture
 * typical information required to generate a CV. This entity can be stored in
 * MongoDB for later retrieval or processing.
 */
@Document(collection = "cvs")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cv {
    @Id
    private String id;
    private String fullName;
    private String email;
    private String phone;
    private String summary;
    private List<String> education;
    private List<String> experience;
    private List<String> skills;
}