package com.afrigenai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the Spring Boot backend application. Running this class
 * launches an embedded web server and exposes the REST API defined in
 * the controllers.
 */
@SpringBootApplication
public class DropshippingBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(DropshippingBackendApplication.class, args);
    }
}