package com.afrigenai.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.afrigenai.model.Service;

/**
 * Mongo repository for persisting and retrieving Service documents. Spring Data
 * automatically implements CRUD operations for us.
 */
public interface ServiceRepository extends MongoRepository<Service, String> {
    // Additional query methods can be declared here if needed
}