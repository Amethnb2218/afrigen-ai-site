package com.afrigenai.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.afrigenai.model.Service;
import com.afrigenai.repository.ServiceRepository;

/**
 * REST controller exposing CRUD endpoints for the Service entity. Clients can
 * retrieve all services, fetch a single service by its identifier and create
 * new services. Update and delete endpoints can be added similarly.
 */
@RestController
@RequestMapping("/api/services")
public class ServiceController {

    private final ServiceRepository serviceRepository;

    public ServiceController(ServiceRepository serviceRepository) {
        this.serviceRepository = serviceRepository;
    }

    /**
     * Retrieve all available services.
     *
     * @return list of services
     */
    @GetMapping
    public List<Service> getAllServices() {
        return serviceRepository.findAll();
    }

    /**
     * Retrieve a service by its identifier.
     *
     * @param id identifier of the service
     * @return the service if found, or 404 not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<Service> getServiceById(@PathVariable String id) {
        return serviceRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Create a new service. The id will be generated automatically by MongoDB.
     *
     * @param service the service to create
     * @return the persisted service
     */
    @PostMapping
    public Service createService(@RequestBody Service service) {
        service.setId(null); // ensure new document
        return serviceRepository.save(service);
    }
}