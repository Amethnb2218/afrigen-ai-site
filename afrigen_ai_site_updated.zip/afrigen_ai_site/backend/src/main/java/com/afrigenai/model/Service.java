package com.afrigenai.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Representation of a service offered by the business. Each service has a
 * unique identifier, a name, a description and a price. Additional fields
 * can be added as needed (e.g. category, image URL, etc.).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "services")
public class Service {

    @Id
    private String id;

    private String name;
    private String description;

    private Double price;
}